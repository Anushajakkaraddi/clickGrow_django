# ClickGrown Django Backend

## Run locally

1. Install Python 3.10+.
2. In this `Backend` folder, create a virtual environment and install dependencies:
   ```powershell
   py -m venv .venv
   .\.venv\Scripts\Activate.ps1
   pip install -r requirements.txt
   ```
3. Create the SQLite tables and start the site:
   ```powershell
   python manage.py migrate
   python manage.py runserver
   ```
4. Visit `http://127.0.0.1:8000/`.

## Routes

- `GET /` – ClickGrown homepage
- `GET, POST /register/` – registration with validation, then redirects home
- `GET, POST /login/` – authentication, then redirects home
- `POST /logout/` – session logout
- `GET /api/health/`
- `POST /api/auth/register/`
- `POST /api/auth/login/`
- `POST /api/auth/logout/`
- `GET /api/auth/me/`

The API uses Django session authentication and CSRF protection. For AJAX requests, include the `csrftoken` cookie value in the `X-CSRFToken` header.
