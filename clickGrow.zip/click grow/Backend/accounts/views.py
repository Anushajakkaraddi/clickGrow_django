import json

from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required
from django.http import JsonResponse
from django.shortcuts import redirect, render
from django.views.decorators.csrf import csrf_protect
from django.views.decorators.http import require_GET, require_POST

from .forms import LoginForm, RegisterForm


def home(request):
    """Serve the existing ClickGrown frontend as the Django homepage."""
    return render(request, "index.html")


@csrf_protect
def register_view(request):
    if request.user.is_authenticated:
        return redirect("home")
    form = RegisterForm(request.POST or None)
    if request.method == "POST" and form.is_valid():
        user = form.save()
        login(request, user)
        return redirect("home")
    return render(request, "accounts/register.html", {"form": form})


@csrf_protect
def login_view(request):
    if request.user.is_authenticated:
        return redirect("home")
    form = LoginForm(request, data=request.POST or None)
    if request.method == "POST" and form.is_valid():
        login(request, form.get_user())
        return redirect(request.POST.get("next") or "home")
    return render(request, "accounts/login.html", {"form": form})


@require_POST
def logout_view(request):
    logout(request)
    return redirect("home")


def _payload(request):
    """Accept JSON APIs while retaining standard Django CSRF protection."""
    try:
        return json.loads(request.body.decode("utf-8")) if request.body else request.POST
    except json.JSONDecodeError:
        return None


def _errors(form):
    return {field: [str(error) for error in errors] for field, errors in form.errors.items()}


@require_GET
def health_api(request):
    return JsonResponse({"status": "ok", "service": "clickgrown-api"})


@require_POST
@csrf_protect
def register_api(request):
    data = _payload(request)
    if data is None:
        return JsonResponse({"detail": "Invalid JSON payload."}, status=400)
    form = RegisterForm(data)
    if not form.is_valid():
        return JsonResponse({"detail": "Validation failed.", "errors": _errors(form)}, status=400)
    user = form.save()
    login(request, user)
    return JsonResponse({"detail": "Account created.", "user": {"id": user.id, "username": user.username, "email": user.email}}, status=201)


@require_POST
@csrf_protect
def login_api(request):
    data = _payload(request)
    if data is None:
        return JsonResponse({"detail": "Invalid JSON payload."}, status=400)
    username = data.get("username", "")
    password = data.get("password", "")
    user = authenticate(request, username=username, password=password)
    if user is None:
        return JsonResponse({"detail": "Invalid username or password."}, status=400)
    login(request, user)
    return JsonResponse({"detail": "Signed in successfully.", "user": {"id": user.id, "username": user.username, "email": user.email}})


@require_POST
@csrf_protect
def logout_api(request):
    logout(request)
    return JsonResponse({"detail": "Signed out successfully."})


@require_GET
@login_required
def me_api(request):
    user = request.user
    return JsonResponse({"id": user.id, "username": user.username, "email": user.email})
