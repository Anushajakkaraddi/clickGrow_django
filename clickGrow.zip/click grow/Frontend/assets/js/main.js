document.addEventListener('DOMContentLoaded', () => {
  const header = document.getElementById('site-header');
  const menuButton = document.getElementById('menu-button');
  const mobileMenu = document.getElementById('mobile-menu');

  window.addEventListener('scroll', () => header.classList.toggle('scrolled', window.scrollY > 16), { passive: true });
  menuButton.addEventListener('click', () => {
    const open = mobileMenu.classList.toggle('hidden') === false;
    menuButton.setAttribute('aria-expanded', String(open));
  });
  mobileMenu.querySelectorAll('a').forEach(link => link.addEventListener('click', () => {
    mobileMenu.classList.add('hidden'); menuButton.setAttribute('aria-expanded', 'false');
  }));

  const formatNumber = (number) => new Intl.NumberFormat('en-US').format(number);
  const counters = document.querySelectorAll('[data-count]');
  const animateCounter = (element) => {
    const target = Number(element.dataset.count); const start = performance.now(); const duration = 1400;
    const tick = (now) => {
      const progress = Math.min((now - start) / duration, 1);
      const value = Math.floor((1 - Math.pow(1 - progress, 3)) * target);
      element.textContent = `${element.dataset.prefix || ''}${formatNumber(value)}${element.dataset.suffix || ''}`;
      if (progress < 1) requestAnimationFrame(tick);
    };
    requestAnimationFrame(tick);
  };
  const observer = new IntersectionObserver(entries => entries.forEach(entry => {
    if (entry.isIntersecting) { animateCounter(entry.target); observer.unobserve(entry.target); }
  }), { threshold: .5 });
  counters.forEach(counter => observer.observe(counter));

  document.getElementById('newsletter-form').addEventListener('submit', (event) => {
    event.preventDefault(); const email = document.getElementById('email'); const message = document.getElementById('form-message');
    if (!email.validity.valid) { email.focus(); return; }
    message.textContent = 'You’re on the list — welcome to the growth notes.'; message.classList.remove('hidden'); event.currentTarget.reset();
  });
});
